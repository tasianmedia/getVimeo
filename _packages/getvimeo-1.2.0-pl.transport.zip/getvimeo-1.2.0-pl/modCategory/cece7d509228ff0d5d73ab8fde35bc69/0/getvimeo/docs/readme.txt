--------------------
Extra: getVimeo
--------------------
Version: 1.2.0-pl
Released: November 15, 2017
Since: June 12, 2013
Author: David Pede <dev@tasianmedia.com> <https://twitter.com/davepede>
Copyright: (C) 2017 David Pede. All rights reserved. <dev@tasianmedia.com>

A simple video retrieval Snippet for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/display/ADDON/getVimeo

GitHub Repository:
http://github.com/tasianmedia/getVimeo

Bugs & Feature Requests:
http://github.com/tasianmedia/getVimeo/issues

Please Note:
getVimeo is not associated with or endorsed by Vimeo, LLC.

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html